package com.example.painel_academico

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
