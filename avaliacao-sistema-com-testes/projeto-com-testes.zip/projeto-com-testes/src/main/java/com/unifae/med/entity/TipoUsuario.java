package com.unifae.med.entity;

public enum TipoUsuario {
    ESTUDANTE,
    PROFESSOR,
    COORDENADOR,
    ADMINISTRADOR
}
